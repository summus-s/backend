export enum PlatformRoleKey {
  SUPERADMIN = 'SUPERADMIN',
  SALES = 'SALES',
  SUPPORT = 'SUPPORT',
  ACCOUNTING = 'ACCOUNTING',
}